# README #

Essa pasta é a pasta padrão onde ficam os arquivos cabeçalhos (*.ch) necessários para a geração das libs. Você pode mudar para outra pasta alterando a variável de ambiente SISTEMAS_PATH_TO_INCLUDE 

